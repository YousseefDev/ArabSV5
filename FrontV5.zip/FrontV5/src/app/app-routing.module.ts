// src/app/app-routing.module.ts

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { HrDashboardComponent } from './hr-dashboard/hr-dashboard.component';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { AuthGuard } from './auth.guard';
import { LeaveRequestComponent } from './requests/leave-request/leave-request.component';
import { LoanRequestComponent } from './requests/loan-request/loan-request.component';
import { AuthRequestComponent } from './requests/auth-request/auth-request.component';
import { DocumentRequestComponent } from './requests/document-request/document-request.component';
import { PersonalSituationRequestComponent } from './requests/personal-situation/personal-situation.component';
import { ProfileComponent } from './profile/profile.component';
import { DashboardComponent } from './dashboard.component';
import { UserRequestsComponent } from './user-requests/user-requests.component';
import { AttendanceComponent } from './app-attendance/app-attendance.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'admin', component: AdminDashboardComponent, canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },
  { path: 'hr', component: HrDashboardComponent, canActivate: [AuthGuard], data: { roles: ['HUMAN_RESOURCE'] } },
  { path: 'employee', component: EmployeeDashboardComponent, canActivate: [AuthGuard], data: { roles: ['EMPLOYEE'] } },
  { path: 'leave', component: LeaveRequestComponent, canActivate: [AuthGuard] },
  { path: 'loan', component: LoanRequestComponent },
  { path: 'auth', component: AuthRequestComponent },
  { path: 'document', component: DocumentRequestComponent },
  { path: 'dashboard', component: DashboardComponent, children: [
    { path: 'profile', component: ProfileComponent } ]},
  { path: 'my-requests', component: UserRequestsComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'attendance', component: AttendanceComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
