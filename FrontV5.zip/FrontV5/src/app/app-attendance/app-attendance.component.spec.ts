import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppAttendanceComponent } from './app-attendance.component';

describe('AppAttendanceComponent', () => {
  let component: AppAttendanceComponent;
  let fixture: ComponentFixture<AppAttendanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppAttendanceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AppAttendanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
