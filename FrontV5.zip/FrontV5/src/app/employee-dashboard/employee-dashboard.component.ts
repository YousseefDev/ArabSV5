import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProfileComponent } from '../profile/profile.component';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.scss']
})
export class EmployeeDashboardComponent {
  showMenu: boolean = false;
  selectedRequestType: string | null = null;
  showProfile: boolean  = false;

  // Injecter le Router dans le constructeur
  constructor(private router: Router,
    private authService: AuthService 
  ) {}

  toggleMenu(): void {
    this.showMenu = !this.showMenu;
  }

  selectRequestType(requestType: string): void {
    this.selectedRequestType = requestType;
    this.showMenu = false;// Fermer le menu une fois qu'une demande est sélectionnée
  }
  
  navigateToProfile(): void {
    this.router.navigate(['profile']);
    
  }
  logout(): void {
    this.authService.logout();
  }

  showUserProfile(): void {
    this.showProfile = true;
  }
}
