import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';


@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersListComponent implements OnInit {
    users: User[] = [];
  
    constructor(private apiService: ApiService) { }
  
    ngOnInit(): void {
      this.fetchUsers();
    }
  
    fetchUsers(): void {
      this.apiService.getAllUsers().subscribe(
        users => {
          this.users = users;
        },
        error => {
          console.error('Error fetching users:', error);
        }
      );
    }
  }
  
  interface User {
    id: number;
    fullName: string;
    email: string;
    // Add other user properties as needed
  }