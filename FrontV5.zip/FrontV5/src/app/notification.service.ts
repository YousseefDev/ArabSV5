import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private notifications: string[] = [];
  private notificationsSubject = new Subject<string[]>();

  notifications$: Observable<string[]> = this.notificationsSubject.asObservable(); // Define notifications$ observable

  constructor() {}

  addNotification(message: string): void {
    this.notifications.push(message);
    this.notificationsSubject.next([...this.notifications]);
  }

  clearNotifications(): void {
    this.notifications = [];
    this.notificationsSubject.next([]);
  }

  sendNewRequestNotification(): void {
    this.addNotification('New request received.');
  }
}
