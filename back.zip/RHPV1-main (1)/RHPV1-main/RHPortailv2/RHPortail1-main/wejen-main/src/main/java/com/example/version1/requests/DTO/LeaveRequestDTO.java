package com.example.version1.requests.DTO;


import lombok.Data;

import java.time.LocalDateTime;

@Data
public class LeaveRequestDTO {
    private String title;
    private String description;
    private String senderFullName;
    private String leaveReason;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private String documentUrl;
}

