package com.example.version1.requests.loan;

import com.example.version1.requests.document.DocumentRequest;
import com.example.version1.users.User;
import com.example.version1.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import javax.naming.AuthenticationException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/requests/loan")
public class LoanRequestController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LoanRequestService loanRequestService;

    @PostMapping("/send-req")
    public ResponseEntity<LoanRequest> createLoanRequest(@RequestBody LoanRequest request, Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new AuthenticationException("Authentication is missing or invalid for this request");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();
        Long userId = user.getId();

        request.setUserId(userId);

        LoanRequest createdRequest = loanRequestService.createLoanRequest(request, userId);
        return new ResponseEntity<>(createdRequest, HttpStatus.CREATED);
    }// LoanRequestController.java
    @PutMapping("/{id}/status")
    public ResponseEntity<LoanRequest> updateLoanRequestStatusAndResponse(@PathVariable Long id,
                                                                          @RequestParam String newStatus,
                                                                          @RequestParam(required = false) String response) {
        LoanRequest updatedRequest = loanRequestService.updateLoanRequestStatusAndResponse(id, newStatus, response);
        return new ResponseEntity<>(updatedRequest, HttpStatus.OK);
    }

    @GetMapping("/my-loan-requests")
    public ResponseEntity<List<LoanRequest>> getMyLoanRequests(Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new AuthenticationException("User not authenticated");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();

        Long userId = user.getId();

        List<LoanRequest> userLoanRequests = loanRequestService.getLoanRequestsByUserId(userId);

        return new ResponseEntity<>(userLoanRequests, HttpStatus.OK);
    }


}